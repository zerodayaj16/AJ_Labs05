# LogSageAI Phase 1

This bundle adds a modular Python backend to the existing Evidence Terminal project.

## Implemented

- JSON object/array, quote-aware CSV, and plain-text parsing
- Canonical field normalization
- IPv4, domain, URL, email, MD5, SHA-1 and SHA-256 extraction
- Ordered MITRE ATT&CK-style tactic and technique mapping
- Severity classification with supplied-severity precedence
- Summary counts for severity, tactics and unique IOCs
- FastAPI endpoints: `GET /health`, `POST /api/v1/analyze`
- Docker support and unit tests

## Run locally

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://localhost:8000/docs`.

## Example request

```json
{
  "format": "text",
  "content": "2026-07-12 10:00:00 Multiple failed login attempts from 8.8.8.8"
}
```

## Test

From the bundle root:

```bash
pytest -q
```

## Repository placement

Copy `backend/`, `sample_logs/`, `docker-compose.yml`, and this README into the root of `zerodayaj16/AJ_Labs05`.
