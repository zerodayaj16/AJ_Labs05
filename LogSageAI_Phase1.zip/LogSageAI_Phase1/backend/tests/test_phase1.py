from backend.app.ioc import extract_iocs
from backend.app.mitre import map_mitre
from backend.app.parser import parse_logs, summarize


def test_ioc_extraction():
    text = "User contacted https://evil.example/login from 8.8.8.8; hash " + "a" * 64
    iocs = extract_iocs(text)
    assert "8.8.8.8" in iocs["ipv4"]
    assert "evil.example" in iocs["domains"]
    assert "https://evil.example/login" in iocs["urls"]
    assert "a" * 64 in iocs["sha256"]


def test_mitre_mapping():
    result = map_mitre("Multiple failed login events indicate password spray")
    assert result["severity"] == "high"
    assert result["technique_id"] == "T1110"


def test_quote_aware_csv_and_summary():
    raw = 'timestamp,user,message\n2026-07-12 10:00:00,ajit,"PowerShell downloaded file, then executed it"\n'
    events = parse_logs(raw, "csv")
    assert len(events) == 1
    assert events[0]["user"] == "ajit"
    assert events[0]["mitre"]["technique_id"] == "T1059.001"
    assert summarize(events)["severity"]["medium"] == 1
