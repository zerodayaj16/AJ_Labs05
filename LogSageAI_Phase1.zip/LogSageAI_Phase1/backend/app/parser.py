import csv
import io
import json
from typing import Any

from .ioc import extract_iocs
from .mitre import map_mitre

FIELD_ALIASES = {
    "timestamp": ("timestamp", "time", "ts", "date", "@timestamp"),
    "message": ("message", "msg", "event", "description", "raw_message"),
    "user": ("user", "username", "actor", "account", "user_name"),
    "host": ("host", "hostname", "computer", "device", "source_host"),
    "source_ip": ("source_ip", "src_ip", "src", "client_ip"),
    "destination_ip": ("destination_ip", "dest_ip", "dst_ip", "dst", "server_ip"),
}


def _pick(obj: dict[str, Any], names: tuple[str, ...]) -> str:
    lowered = {str(k).lower(): v for k, v in obj.items()}
    for name in names:
        value = lowered.get(name.lower())
        if value not in (None, ""):
            return str(value)
    return ""


def normalize_event(obj: dict[str, Any], index: int = 0) -> dict[str, Any]:
    message = _pick(obj, FIELD_ALIASES["message"]) or json.dumps(obj, ensure_ascii=False, default=str)
    combined = f"{message} {json.dumps(obj, ensure_ascii=False, default=str)}"
    mitre = map_mitre(combined)
    supplied_severity = str(obj.get("severity") or obj.get("level") or "").lower()
    severity = supplied_severity if supplied_severity in {"critical", "high", "medium", "low"} else mitre["severity"]
    return {
        "id": index,
        "timestamp": _pick(obj, FIELD_ALIASES["timestamp"]),
        "message": message,
        "user": _pick(obj, FIELD_ALIASES["user"]),
        "host": _pick(obj, FIELD_ALIASES["host"]),
        "source_ip": _pick(obj, FIELD_ALIASES["source_ip"]),
        "destination_ip": _pick(obj, FIELD_ALIASES["destination_ip"]),
        "severity": severity,
        "mitre": {
            "tactic": mitre["tactic"],
            "technique_id": mitre["technique_id"],
            "technique": mitre["technique"],
        },
        "iocs": extract_iocs(combined),
        "raw": obj,
    }


def parse_json(raw: str) -> list[dict[str, Any]]:
    value = json.loads(raw)
    if isinstance(value, dict):
        value = value.get("events") or value.get("logs") or [value]
    if not isinstance(value, list):
        raise ValueError("JSON input must be an object or an array of objects")
    return [normalize_event(item if isinstance(item, dict) else {"message": str(item)}, i) for i, item in enumerate(value)]


def parse_csv(raw: str) -> list[dict[str, Any]]:
    reader = csv.DictReader(io.StringIO(raw))
    if not reader.fieldnames:
        raise ValueError("CSV input requires a header row")
    return [normalize_event(dict(row), i) for i, row in enumerate(reader)]


def parse_text(raw: str) -> list[dict[str, Any]]:
    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    events = []
    for i, line in enumerate(lines):
        timestamp = ""
        if len(line) >= 19 and line[4:5] == "-" and line[7:8] == "-":
            timestamp, line = line[:19], line[19:].strip()
        events.append(normalize_event({"timestamp": timestamp, "message": line}, i))
    return events


def parse_logs(raw: str, format_hint: str | None = None) -> list[dict[str, Any]]:
    raw = raw.strip()
    if not raw:
        return []
    hint = (format_hint or "").lower()
    if hint == "json" or raw.startswith(("[", "{")):
        try:
            return parse_json(raw)
        except (json.JSONDecodeError, ValueError):
            if hint == "json":
                raise
    if hint == "csv" or ("\n" in raw and "," in raw.splitlines()[0]):
        try:
            return parse_csv(raw)
        except (csv.Error, ValueError):
            if hint == "csv":
                raise
    return parse_text(raw)


def summarize(events: list[dict[str, Any]]) -> dict[str, Any]:
    severity = {key: 0 for key in ("critical", "high", "medium", "low")}
    tactics: dict[str, int] = {}
    ioc_totals = {key: set() for key in ("ipv4", "domains", "urls", "emails", "md5", "sha1", "sha256")}
    for event in events:
        severity[event["severity"]] = severity.get(event["severity"], 0) + 1
        tactic = event["mitre"]["tactic"]
        if tactic:
            tactics[tactic] = tactics.get(tactic, 0) + 1
        for key, values in event["iocs"].items():
            ioc_totals[key].update(values)
    return {
        "total_events": len(events),
        "severity": severity,
        "tactics": dict(sorted(tactics.items(), key=lambda item: (-item[1], item[0]))),
        "unique_iocs": {key: len(values) for key, values in ioc_totals.items()},
    }
