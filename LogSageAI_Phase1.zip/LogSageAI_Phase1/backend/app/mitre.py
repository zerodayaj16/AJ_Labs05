from dataclasses import dataclass

@dataclass(frozen=True)
class MitreRule:
    severity: str
    tactic: str | None
    technique_id: str | None
    technique: str | None
    keywords: tuple[str, ...]

RULES = (
    MitreRule("critical", "Impact", "T1486", "Data Encrypted for Impact", ("ransomware", "mass file encryption", "wiper", "encrypted your files")),
    MitreRule("critical", "Command and Control", "T1071", "Application Layer Protocol", ("command and control", "known malicious ip", "backdoor", "beacon", " c2 ")),
    MitreRule("critical", "Exfiltration", "T1041", "Exfiltration Over C2 Channel", ("exfiltrat", "large outbound transfer", "data leak", "upload to unknown host")),
    MitreRule("high", "Credential Access", "T1110", "Brute Force", ("brute force", "password spray", "failed login", "invalid credentials", "account locked")),
    MitreRule("high", "Privilege Escalation", "T1078", "Valid Accounts", ("privilege escalation", "admin group membership", "sudo added", "elevated to administrator")),
    MitreRule("high", "Defense Evasion", "T1027", "Obfuscated Files or Information", ("encoded command", "obfuscated", "disabled logging", "cleared event log", "antivirus disabled")),
    MitreRule("high", "Lateral Movement", "T1021", "Remote Services", ("psexec", "pass-the-hash", "lateral movement", "smb admin share", "unusual rdp")),
    MitreRule("high", "Initial Access", "T1566", "Phishing", ("phishing", "malicious attachment", "exploit public-facing", "malware signature detected")),
    MitreRule("medium", "Persistence", "T1053", "Scheduled Task/Job", ("scheduled task created", "registry run key", "startup entry added")),
    MitreRule("medium", "Persistence", "T1136", "Create Account", ("new user account created",)),
    MitreRule("medium", "Discovery", "T1046", "Network Service Discovery", ("port scan", "network scan", "subnet scan")),
    MitreRule("medium", "Discovery", "T1033", "System Owner/User Discovery", ("whoami",)),
    MitreRule("medium", "Execution", "T1059.001", "PowerShell", ("powershell", "encodedcommand")),
    MitreRule("medium", "Execution", "T1059.003", "Windows Command Shell", ("cmd.exe spawned", "command shell")),
)

def map_mitre(text: str) -> dict[str, str | None]:
    haystack = f" {text.lower()} "
    for rule in RULES:
        if any(keyword in haystack for keyword in rule.keywords):
            return {
                "severity": rule.severity,
                "tactic": rule.tactic,
                "technique_id": rule.technique_id,
                "technique": rule.technique,
            }
    return {"severity": "low", "tactic": None, "technique_id": None, "technique": None}
