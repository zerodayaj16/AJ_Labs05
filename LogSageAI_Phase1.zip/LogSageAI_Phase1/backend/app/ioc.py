import ipaddress
import re
from urllib.parse import urlparse

URL_RE = re.compile(r"https?://[^\s\]\[<>{}\"']+", re.I)
IP_RE = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])")
DOMAIN_RE = re.compile(r"(?<![@\w.-])(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?![\w.-])", re.I)
EMAIL_RE = re.compile(r"\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}\b", re.I)
MD5_RE = re.compile(r"\b[a-f0-9]{32}\b", re.I)
SHA1_RE = re.compile(r"\b[a-f0-9]{40}\b", re.I)
SHA256_RE = re.compile(r"\b[a-f0-9]{64}\b", re.I)


def _valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def extract_iocs(text: str) -> dict[str, list[str]]:
    urls = sorted(set(URL_RE.findall(text)))
    ips = sorted({value for value in IP_RE.findall(text) if _valid_ip(value)})
    emails = sorted(set(EMAIL_RE.findall(text)))
    domains = set(DOMAIN_RE.findall(text))
    domains.update(urlparse(url).hostname for url in urls if urlparse(url).hostname)
    domains.difference_update(email.split("@", 1)[1] for email in emails)
    hashes = {
        "md5": sorted(set(MD5_RE.findall(text))),
        "sha1": sorted(set(SHA1_RE.findall(text))),
        "sha256": sorted(set(SHA256_RE.findall(text))),
    }
    return {
        "ipv4": ips,
        "domains": sorted(d for d in domains if d),
        "urls": urls,
        "emails": emails,
        "md5": hashes["md5"],
        "sha1": hashes["sha1"],
        "sha256": hashes["sha256"],
    }
