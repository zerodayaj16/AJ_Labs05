from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .parser import parse_logs, summarize

app = FastAPI(title="LogSageAI API", version="0.1.0", description="Phase 1 SOC log parsing, IOC extraction and MITRE ATT&CK mapping API")

class AnalyzeRequest(BaseModel):
    content: str = Field(min_length=1)
    format: str | None = Field(default=None, pattern="^(json|csv|text)?$")

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "logsageai"}

@app.post("/api/v1/analyze")
def analyze(request: AnalyzeRequest) -> dict:
    try:
        events = parse_logs(request.content, request.format)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"summary": summarize(events), "events": events}
